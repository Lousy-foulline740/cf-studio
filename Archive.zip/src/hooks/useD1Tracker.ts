import { useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import { useAppStore } from "@/store/useAppStore";
import { type D1QueryResult } from "@/hooks/useCloudflare";

export type ExecutionSource = "UI_ACTION" | "RAW_QUERY";

export interface TrackedQueryOptions {
  query: string;
  databaseId: string;
  accountId: string;
  tableName?: string | null;
  source: ExecutionSource;
}

/**
 * Unified wrapper hook for all D1 API interactions.
 * Centralizes logging to the local SQLite database.
 */
export function useD1Tracker() {
  const sessionId = useAppStore((state) => state.sessionId);
  const activeAccountId = useAppStore((state) => state.activeAccount?.id);
  const saveQueryResultsEnabled = useAppStore((state) => state.saveQueryResultsEnabled);
  const saveQueryResultsRowLimit = useAppStore((state) => state.saveQueryResultsRowLimit);

  const executeTrackedQuery = useCallback(
    async (
      options: TrackedQueryOptions,
      executeNetworkCall: () => Promise<D1QueryResult[]>
    ): Promise<D1QueryResult[]> => {
      const resolvedAccountId = options.accountId || activeAccountId || "";

      const getResultData = (results: D1QueryResult[]) => {
        if (!saveQueryResultsEnabled) return null;
        const rows = results[0]?.results;
        if (!rows) return null;
        const limitedRows = saveQueryResultsRowLimit == null
          ? rows
          : rows.slice(0, Math.max(1, saveQueryResultsRowLimit));
        return JSON.stringify(limitedRows);
      };
      try {
        // 1. Execute the actual Cloudflare D1 API request
        const results = await executeNetworkCall();

        // 2. Extract metrics (Cloudflare API returns these in the meta block)
        const totalRowsRead = results.reduce(
          (sum, r) => sum + (r.meta?.rows_read || 0),
          0
        );

        // 3. Fire and forget tracking log to local SQLite
        const successPayload = {
          accountId: resolvedAccountId,
          databaseId: options.databaseId,
          sessionId: sessionId,
          executionSource: options.source,
          tableName: options.tableName || null,
          queryText: options.query,
          rowsRead: totalRowsRead,
          // Store the raw JSON results for the history view
          resultData: getResultData(results),
        };
        console.log("Sending to Tauri:", successPayload);
        invoke("save_query_history", successPayload)
          .catch((err) => console.error("Tauri Save Error:", err));

        return results;
      } catch (error) {
        // Log the failed query state to history as well
        const errorPayload = {
          accountId: resolvedAccountId,
          databaseId: options.databaseId,
          sessionId: sessionId,
          executionSource: options.source,
          tableName: options.tableName || null,
          queryText: options.query,
          rowsRead: 0,
          resultData: null,
        };
        console.log("Sending to Tauri:", errorPayload);
        invoke("save_query_history", errorPayload)
          .catch((err) => console.error("Tauri Save Error:", err));

        throw error;
      }
    },
    [sessionId, activeAccountId, saveQueryResultsEnabled, saveQueryResultsRowLimit]
  );

  return { executeTrackedQuery };
}
