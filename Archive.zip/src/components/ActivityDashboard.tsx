import { useEffect, useState, useCallback, useMemo } from "react";
import { invoke } from "@tauri-apps/api/core";
import { 
  Terminal, 
  MousePointer2, 
  Search, 
  ChevronLeft, 
  ChevronRight,
  Zap,
  Activity,
  Clock,
  Filter,
  Layers,
  Eye
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/useAppStore";
import { useCloudflareAccounts, useD1Databases } from "@/hooks/useCloudflare";
import { ExportWrapper } from "@/components/ExportWrapper";

interface QueryHistoryEntry {
  id: number;
  account_id: string;
  query_text: string;
  database_id: string;
  session_id: string;
  execution_source: string;
  table_name: string | null;
  rows_read: number;
  result_data: string | null;
  timestamp: string;
}

interface GlobalStats {
  total_queries: number;
  total_reads: number;
}

interface HistoryDebugStatus {
  db_path: string | null;
  row_count: number;
  last_query_text: string | null;
  last_timestamp: string | null;
}

const PAGE_SIZE = 50;

export function ActivityDashboard() {
  useCloudflareAccounts();
  useD1Databases();
  const activeAccount = useAppStore(state => state.activeAccount);
  const databases = useAppStore(state => state.databases);
  
  const [history, setHistory] = useState<QueryHistoryEntry[]>([]);
  const [globalStats, setGlobalStats] = useState<GlobalStats>({ total_queries: 0, total_reads: 0 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedDb, setSelectedDb] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(0);
  const [resultOpen, setResultOpen] = useState(false);
  const [resultItem, setResultItem] = useState<QueryHistoryEntry | null>(null);
  const [exportOpen, setExportOpen] = useState(false);
  
  const [dateRange, setDateRange] = useState<string>("lifetime");
  const [customStart, setCustomStart] = useState<string>("");
  const [customEnd, setCustomEnd] = useState<string>("");

  const computedDates = useMemo(() => {
    let start: string | null = null;
    let end: string | null = null;

    if (dateRange === "today") {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      start = d.toISOString().replace("T", " ").replace("Z", "");
    } else if (dateRange === "week") {
      const d = new Date();
      d.setDate(d.getDate() - d.getDay()); // Sunday
      d.setHours(0, 0, 0, 0);
      start = d.toISOString().replace("T", " ").replace("Z", "");
    } else if (dateRange === "month") {
      const d = new Date();
      d.setDate(1);
      d.setHours(0, 0, 0, 0);
      start = d.toISOString().replace("T", " ").replace("Z", "");
    } else if (dateRange === "year") {
      const d = new Date();
      d.setMonth(0, 1);
      d.setHours(0, 0, 0, 0);
      start = d.toISOString().replace("T", " ").replace("Z", "");
    } else if (dateRange === "custom") {
      if (customStart) {
        start = new Date(customStart).toISOString().replace("T", " ").replace("Z", "");
      }
      if (customEnd) {
        const d = new Date(customEnd);
        d.setHours(23, 59, 59, 999);
        end = d.toISOString().replace("T", " ").replace("Z", "");
      }
    }
    return { start, end };
  }, [dateRange, customStart, customEnd]);

  const fetchHistory = useCallback(async () => {
    const accountId = activeAccount?.id ?? null;
    try {
      setLoading(true);
      const [data, stats] = await Promise.all([
        invoke<QueryHistoryEntry[]>("get_paginated_history", { 
          accountId,
          databaseId: selectedDb === "all" ? null : selectedDb,
          limit: PAGE_SIZE,
          offset: currentPage * PAGE_SIZE,
          startDate: computedDates.start,
          endDate: computedDates.end
        }),
        invoke<GlobalStats>("get_global_stats", {
          accountId,
          startDate: computedDates.start,
          endDate: computedDates.end
        })
      ]);
      console.log("Fetched History:", data);
      setHistory(data);
      setGlobalStats(stats);
    } catch (error) {
      console.error("Failed to fetch history:", error);
    } finally {
      setLoading(false);
    }
  }, [activeAccount?.id, selectedDb, currentPage, computedDates]);

  useEffect(() => {
    invoke<HistoryDebugStatus>("get_history_debug_status")
      .then((status) => console.log("History Debug Status:", status))
      .catch((err) => console.error("History Debug Status Error:", err));
    fetchHistory();
  }, [fetchHistory]);

  const filteredHistory = useMemo(() => {
    return history.filter(item => 
      item.query_text.toLowerCase().includes(search.toLowerCase()) ||
      item.database_id.toLowerCase().includes(search.toLowerCase()) ||
      (item.table_name && item.table_name.toLowerCase().includes(search.toLowerCase()))
    );
  }, [history, search]);

  const groupedBySession = useMemo(() => {
    const groups: Record<string, QueryHistoryEntry[]> = {};
    for (const item of filteredHistory) {
      const sid = item.session_id || "default";
      if (!groups[sid]) groups[sid] = [];
      groups[sid].push(item);
    }
    return Object.entries(groups).sort((a, b) => {
      const tA = new Date(a[1][0]?.timestamp).getTime();
      const tB = new Date(b[1][0]?.timestamp).getTime();
      return tB - tA;
    });
  }, [filteredHistory]);

  const formatNumber = (num: number) => new Intl.NumberFormat().format(num);

  const resultPayload = useMemo(() => {
    if (!resultItem?.result_data) {
      return { rows: [] as Record<string, unknown>[], columns: [] as string[], error: "No result data saved for this history item." };
    }
    try {
      const json = JSON.parse(resultItem.result_data);
      if (!Array.isArray(json)) {
        return { rows: [] as Record<string, unknown>[], columns: [] as string[], error: "Saved results are not a row array." };
      }
      const rows = json as Record<string, unknown>[];
      const columns = Array.from(
        rows.reduce((acc, row) => {
          Object.keys(row || {}).forEach((k) => acc.add(k));
          return acc;
        }, new Set<string>())
      );
      return { rows, columns, error: null as string | null };
    } catch (err) {
      return { rows: [] as Record<string, unknown>[], columns: [] as string[], error: `Failed to parse saved results as JSON: ${String(err)}` };
    }
  }, [resultItem]);
  const formatDateTime = useCallback((ts: string, mode: "full" | "time" = "full") => {
    if (!ts) return "—";
    // SQLite CURRENT_TIMESTAMP is UTC like "YYYY-MM-DD HH:MM:SS"
    // We need to convert it to ISO format and append 'Z' for UTC
    let dateStr = ts;
    if (ts.includes(" ") && !ts.includes("Z") && !ts.includes("+")) {
      dateStr = ts.replace(" ", "T") + "Z";
    }
    const d = new Date(dateStr);
    return mode === "full" ? d.toLocaleString() : d.toLocaleTimeString();
  }, []);

  return (
    <div className="flex flex-col h-screen bg-background text-foreground select-none overflow-hidden font-sans">
      {/* ── Top Header with Date Selection ── */}
      <div className="px-6 py-4 border-b border-border/50 bg-muted/30 backdrop-blur-md flex items-center justify-between gap-4 sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <div className="flex flex-col gap-1">
            <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground/70">Activity Period</h2>
            <Tabs value={dateRange} onValueChange={(v) => { setDateRange(v); setCurrentPage(0); }} className="w-auto">
              <TabsList className="bg-background/50 border border-border/50 p-1 h-9">
                <TabsTrigger value="lifetime" className="text-[10px] px-3 py-1">Lifetime</TabsTrigger>
                <TabsTrigger value="today" className="text-[10px] px-3 py-1">Today</TabsTrigger>
                <TabsTrigger value="week" className="text-[10px] px-3 py-1">Week</TabsTrigger>
                <TabsTrigger value="month" className="text-[10px] px-3 py-1">Month</TabsTrigger>
                <TabsTrigger value="year" className="text-[10px] px-3 py-1">Year</TabsTrigger>
                <TabsTrigger value="custom" className="text-[10px] px-3 py-1">Custom</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {dateRange === "custom" && (
            <div className="flex flex-col gap-1">
              <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground/70">Range</h2>
              <div className="flex items-center gap-2 bg-background/50 border border-border/50 p-1 rounded-md h-9">
                <Input 
                  type="date" 
                  className="h-7 w-28 border-none bg-transparent text-[10px] focus-visible:ring-0 px-1" 
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                />
                <span className="text-muted-foreground/50 text-[10px] px-1">→</span>
                <Input 
                  type="date" 
                  className="h-7 w-28 border-none bg-transparent text-[10px] focus-visible:ring-0 px-1" 
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-1 items-end">
           <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground/70">Search</h2>
           <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/50" />
            <Input 
              placeholder="Search history..." 
              className="h-9 pl-9 bg-background/50 border-border/50 focus:border-primary/50 text-xs placeholder:text-muted-foreground/40 rounded-lg shadow-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
      {/* ── Metric Banner ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6 bg-gradient-to-b from-muted/20 to-transparent">
        <Card className="bg-card border-border/50 backdrop-blur-sm group hover:border-primary/30 transition-all shadow-sm">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground/60 mb-1">Rows Read during Period</p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold tracking-tight font-mono text-foreground">
                  {formatNumber(globalStats.total_reads)}
                </span>
                <span className="text-xs text-muted-foreground font-medium">ROWS</span>
              </div>
            </div>
            <div className="p-3 rounded-2xl bg-amber-500/10 text-amber-500 group-hover:scale-110 transition-transform">
              <Zap size={24} fill="currentColor" className="opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border/50 backdrop-blur-sm group hover:border-primary/30 transition-all shadow-sm">
          <CardContent className="p-6 flex items-center justify-between">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground/60 mb-1">Queries execution count</p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold tracking-tight font-mono text-foreground">
                  {formatNumber(globalStats.total_queries)}
                </span>
                <span className="text-xs text-muted-foreground font-medium">OPS</span>
              </div>
            </div>
            <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-500 group-hover:scale-110 transition-transform">
              <Activity size={24} className="opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Database Selector ── */}
      <div className="px-6 py-2 sticky top-0 z-10 bg-background/50 backdrop-blur-md">
        <Tabs value={selectedDb} onValueChange={(v) => { setSelectedDb(v); setCurrentPage(0); }} className="w-full">
            <ScrollArea className="w-full whitespace-nowrap">
              <TabsList className="bg-muted/30 border border-border/50 p-1 inline-flex w-max min-w-full rounded-xl">
                <TabsTrigger value="all" className="text-xs px-4 py-1.5 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm transition-all rounded-lg">
                  All Databases
                </TabsTrigger>
                {databases.map(db => (
                  <TabsTrigger key={db.uuid} value={db.uuid} className="text-xs px-4 py-1.5 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm transition-all rounded-lg">
                    {db.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </ScrollArea>
          </Tabs>
      </div>

      {/* ── History List ── */}
      <div className="flex-1">
          <div className="max-w-5xl mx-auto p-6">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-24 gap-4">
                <div className="w-8 h-8 border-2 border-border border-t-primary rounded-full animate-spin" />
                <p className="text-xs text-muted-foreground font-medium animate-pulse">Loading activity logs...</p>
              </div>
            ) : groupedBySession.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-32 border-2 border-dashed border-border/50 rounded-3xl bg-muted/5">
                <div className="p-4 rounded-full bg-muted/30 text-muted-foreground/30 mb-4">
                  <Filter size={32} strokeWidth={1.5} />
                </div>
                <h3 className="text-sm font-semibold text-muted-foreground">No activity found</h3>
                <p className="text-xs text-muted-foreground/60 mt-1">Try adjusting your filters or database selection.</p>
              </div>
            ) : (
              <div className="space-y-12 pb-12">
                {groupedBySession.map(([sessionId, items]) => (
                  <div key={sessionId} className="space-y-4">
                    <div className="flex items-center gap-4 group">
                      <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-muted/50 border border-border/50 shadow-sm transition-colors group-hover:border-border">
                        <Clock size={12} className="text-muted-foreground" />
                        <span className="text-[10px] font-bold text-muted-foreground font-mono tracking-tight uppercase underline decoration-border underline-offset-4">
                          Session: {sessionId.slice(0, 8)}...
                        </span>
                        <span className="text-[10px] text-muted-foreground/60 font-medium ml-1">
                          {formatDateTime(items[0].timestamp)}
                        </span>
                      </div>
                      <div className="h-px flex-1 bg-gradient-to-r from-border/50 to-transparent" />
                    </div>

                    <div className="grid gap-3">
                      {items.map((item) => (
                        <div 
                          key={item.id} 
                          className="group relative flex flex-col gap-3 p-4 rounded-2xl border border-border/40 bg-muted/10 hover:bg-muted/20 transition-all hover:border-border/60 shadow-sm"
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex items-center gap-3">
                              {item.execution_source === "UI_ACTION" ? (
                                <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                                  <MousePointer2 size={14} strokeWidth={2.5} />
                                </div>
                              ) : (
                                <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                                  <Terminal size={14} strokeWidth={2.5} />
                                </div>
                              )}
                              
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <Badge variant="outline" className={cn(
                                    "h-5 px-1.5 text-[9px] font-bold tracking-wider",
                                    item.execution_source === "UI_ACTION" 
                                      ? "bg-purple-500/5 text-purple-400 border-purple-500/20" 
                                      : "bg-blue-500/5 text-blue-400 border-blue-500/20"
                                  )}>
                                    {item.execution_source === "RAW_QUERY" ? "SQL_EDITOR" : item.execution_source}
                                  </Badge>
                                  {item.table_name && (
                                    <Badge variant="outline" className="h-5 px-1.5 text-[9px] bg-muted/50 text-muted-foreground border-border/50 gap-1 capitalize">
                                      <Layers size={10} /> {item.table_name}
                                    </Badge>
                                  )}
                                  <span className={cn(
                                    "text-[10px] font-mono font-bold px-1.5 py-0.5 rounded",
                                    item.rows_read > 1000 
                                      ? "bg-red-500/20 text-red-500 border border-red-500/30 animate-pulse" 
                                      : "bg-muted/50 text-muted-foreground"
                                  )}>
                                    {item.rows_read} rows read
                                  </span>
                                </div>
                                <p className="text-[10px] text-muted-foreground">
                                  {formatDateTime(item.timestamp, "time")} • {databases.find(d => d.uuid === item.database_id)?.name || "Unknown DB"}
                                </p>
                              </div>
                            </div>
                            {item.result_data && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-7 px-2 text-[10px] text-muted-foreground border-border/60 hover:bg-accent hover:text-accent-foreground"
                                onClick={() => {
                                  setResultItem(item);
                                  setResultOpen(true);
                                }}
                              >
                                <Eye size={12} className="mr-1.5" />
                                View Results
                              </Button>
                            )}
                          </div>

                          <div className="relative overflow-hidden rounded-xl border border-border/50 bg-muted/30">
                            <pre className="p-3 text-[11px] font-mono text-foreground/90 overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-32 scrollbar-thin scrollbar-thumb-border">
                              {item.query_text}
                            </pre>
                            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-foreground hover:bg-accent" title="Copy SQL">
                                <Filter size={10} />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>

      <Dialog open={resultOpen} onOpenChange={setResultOpen}>
        <DialogContent className="max-w-5xl max-h-[85vh] p-0 overflow-hidden border-border bg-background">
          <DialogHeader className="p-5 border-b border-border/60">
            <div className="flex items-center justify-between gap-4">
              <div>
                <DialogTitle className="text-sm font-semibold text-foreground flex items-center gap-2">
                  Saved Results
                  <span className="text-[10px] font-mono text-muted-foreground">
                    ({formatNumber(resultPayload.rows.length)} rows)
                  </span>
                </DialogTitle>
                {resultItem && (
                  <p className="text-[10px] text-muted-foreground">
                    {resultItem.execution_source === "RAW_QUERY" ? "SQL_EDITOR" : resultItem.execution_source} •{" "}
                    {formatDateTime(resultItem.timestamp)}
                  </p>
                )}
              </div>
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1.5"
                onClick={() => setExportOpen(true)}
                disabled={resultPayload.rows.length === 0}
              >
                Export
              </Button>
            </div>
          </DialogHeader>
          <div className="p-5 overflow-auto">
            {resultPayload.error ? (
              <div className="text-xs text-destructive">{resultPayload.error}</div>
            ) : resultPayload.rows.length === 0 ? (
              <div className="text-xs text-muted-foreground">No rows saved for this history item.</div>
            ) : (
              <div className="border border-border/60 rounded-lg overflow-hidden">
                <div className="max-h-[60vh] overflow-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/30 hover:bg-muted/30 sticky top-0 z-10">
                        {resultPayload.columns.map((col) => (
                          <TableHead key={col} className="text-xs font-semibold">
                            {col}
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {resultPayload.rows.map((row, idx) => (
                        <TableRow key={idx}>
                          {resultPayload.columns.map((col) => {
                            const value = (row as Record<string, unknown>)[col];
                            const text = value == null
                              ? ""
                              : typeof value === "object"
                                ? JSON.stringify(value)
                                : String(value);
                            return (
                              <TableCell key={col} className="text-xs text-foreground/90">
                                {text}
                              </TableCell>
                            );
                          })}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <ExportWrapper
        isOpen={exportOpen}
        onClose={() => setExportOpen(false)}
        dataToExport={resultPayload.rows}
        allColumns={resultPayload.columns}
      />

      {/* ── Pagination Footer ── */}
      <div className="px-6 py-4 border-t border-border/50 bg-background/80 backdrop-blur-md flex items-center justify-between">
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-medium font-mono uppercase tracking-widest">
          Page {currentPage + 1}
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" size="sm" 
            className="h-8 gap-1 border-border bg-transparent hover:bg-accent transition-all text-xs"
            onClick={() => setCurrentPage(p => Math.max(0, p - 1))}
            disabled={currentPage === 0 || loading}
          >
            <ChevronLeft size={14} />
            Prev
          </Button>
          <Button 
            variant="outline" size="sm" 
            className="h-8 gap-1 border-border bg-transparent hover:bg-accent transition-all text-xs"
            onClick={() => setCurrentPage(p => p + 1)}
            disabled={history.length < PAGE_SIZE || loading}
          >
            Next
            <ChevronRight size={14} />
          </Button>
        </div>
      </div>
    </div>
  );
}
