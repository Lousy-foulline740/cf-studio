// R2Explorer.tsx
//
// Full R2 File Manager UI — navigate folders, upload files, download, and delete.
//
// Pro features (Upload, Download, Settings) are gated via the remote config
// at pro.cfstudio.dev/config.json using <R2ProGate> / useProFeature.

import { useState, useEffect, useMemo } from "react";
import { ArrowLeft, RefreshCw, Folder, File, Download, Trash2, UploadCloud, ChevronRight, Globe, Lock, Link as LinkIcon, FileText, Image as ImageIcon, Video, Music, Archive, Code, Settings } from "lucide-react";
import { save as saveDialog } from "@tauri-apps/plugin-dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle as AlertTitle,
} from "@/components/ui/alert-dialog";
import { listen, type UnlistenFn } from "@tauri-apps/api/event";
import { cn } from "@/lib/utils";
import { R2Bucket, R2Object, FolderListing, listR2Objects, uploadR2Object, downloadR2Object, deleteR2Object, cancelUploadR2Object, getR2BucketDomain } from "@/lib/r2";
import { useAppStore } from "@/store/useAppStore";
import { stat } from "@tauri-apps/plugin-fs";
import { useRemoteConfig } from "./useRemoteConfig";
import { PurchaseScreen } from "./PurchaseScreen";
import { R2BucketSettingsModal } from "./R2BucketSettingsModal";
import { R2UploadModal } from "./R2UploadModal";
import { R2ProGate, useProFeature } from "@/components/R2ProGate";

function formatBytes(bytes?: number): string {
  if (bytes === undefined || bytes === null) return "—";
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

function getFileIcon(filename: string) {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  switch (ext) {
    case 'jpg': case 'jpeg': case 'png': case 'gif': case 'webp': case 'svg': case 'ico':
      return <ImageIcon size={14} className="text-blue-500 shrink-0" />;
    case 'mp4': case 'webm': case 'mkv': case 'mov': case 'avi':
      return <Video size={14} className="text-purple-500 shrink-0" />;
    case 'mp3': case 'wav': case 'ogg': case 'flac':
      return <Music size={14} className="text-pink-500 shrink-0" />;
    case 'zip': case 'rar': case '7z': case 'tar': case 'gz': case 'bz2':
      return <Archive size={14} className="text-amber-500 shrink-0" />;
    case 'js': case 'ts': case 'jsx': case 'tsx': case 'json': case 'html': case 'css': case 'rs': case 'go': case 'py': case 'php': case 'sql':
      return <Code size={14} className="text-emerald-500 shrink-0" />;
    case 'txt': case 'md': case 'csv': case 'log':
      return <FileText size={14} className="text-slate-500 shrink-0" />;
    case 'pdf':
      return <FileText size={14} className="text-red-500 shrink-0" />;
    default:
      return <File size={14} className="text-muted-foreground shrink-0" />;
  }
}

function formatDate(iso?: string): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric", month: "short", day: "numeric",
    hour: "2-digit", minute: "2-digit",
  }).format(new Date(iso));
}

interface R2ExplorerProps {
  bucket: R2Bucket;
  onBack: () => void;
}

export function R2Explorer({ bucket, onBack }: R2ExplorerProps) {
  const privacySettings = useAppStore(s => s.privacySettings);
  const blurFile = privacySettings.enabled && privacySettings.r2FileNames;
  const blurBucket = privacySettings.enabled && privacySettings.r2BucketNames;

  const [prefix, setPrefix] = useState<string>("");
  const [listing, setListing] = useState<FolderListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [showPurchaseScreen, setShowPurchaseScreen] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{
    id: string;
    bucketName: string;
    key: string;
    bytes: number;
    total: number;
    speedBps: number;
    startTime: number;
  } | null>(null);
  
  const [publicUrl, setPublicUrl] = useState<string | null | undefined>(undefined);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [confirmDeleteKey, setConfirmDeleteKey] = useState<string | null>(null);
  const { toast } = useToast();
  
  const { data: config } = useRemoteConfig();

  // Pro feature gates (imperative)
  const uploadGate = useProFeature("r2_upload");
  const downloadGate = useProFeature("r2_download");
  const settingsGate = useProFeature("r2_bucket_settings");

  const fetchDomain = async () => {
    try {
      const url = await getR2BucketDomain(bucket.name);
      setPublicUrl(url);
    } catch (err) {
      console.error("Failed to fetch domain", err);
      setPublicUrl(null);
    }
  };

  useEffect(() => {
    fetchDomain();
  }, [bucket.name]);

  useEffect(() => {
    let unlistenFn: UnlistenFn | undefined;
    listen<any>("upload-progress", (event) => {
      const { upload_id, bytes_uploaded, total_bytes } = event.payload;
      setUploadProgress((prev) => {
        if (!prev || prev.id !== upload_id) return prev;
        const now = Date.now();
        const elapsedSec = (now - prev.startTime) / 1000;
        const speedBps = elapsedSec > 0.5 ? bytes_uploaded / elapsedSec : prev.speedBps;
        return { ...prev, bytes: bytes_uploaded, total: total_bytes, speedBps };
      });
    }).then(unlisten => {
      unlistenFn = unlisten;
    });
    return () => {
      if (unlistenFn) unlistenFn();
    };
  }, []);

  const loadObjects = async (targetPrefix: string = prefix) => {
    setLoading(true);
    try {
      const data = await listR2Objects(bucket.name, targetPrefix);
      setListing(data);
    } catch (err: any) {
      console.error("Failed to list objects:", err);
      alert("Failed to list objects: " + err.toString());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadObjects();
  }, [bucket.name, prefix]);

  const handleNavigate = (newPrefix: string) => {
    setPrefix(newPrefix);
  };

  const handleBreadcrumbClick = (index: number) => {
    const parts = prefix.split('/').filter(Boolean);
    const newPrefix = parts.slice(0, index + 1).join('/') + '/';
    setPrefix(newPrefix);
  };

  const handleConfirmUpload = async (selectedPath: string) => {
    if (!uploadGate.isAvailable) { uploadGate.showProToast(); return; }
    try {
      setShowUploadModal(false);

      const isWindows = selectedPath.includes('\\');
      const filename = selectedPath.split(isWindows ? '\\' : '/').pop() || "unknown_file";
      const destKey = prefix + filename;

      const uploadId = crypto.randomUUID();
      let totalSize = 0;
      try {
        const fileStat = await stat(selectedPath);
        totalSize = fileStat.size;
      } catch (e) {}

      setUploading(true);
      setUploadProgress({
        id: uploadId,
        bucketName: bucket.name,
        key: destKey,
        bytes: 0,
        total: totalSize,
        speedBps: 0,
        startTime: Date.now(),
      });

      try {
        await uploadR2Object(bucket.name, destKey, selectedPath, uploadId);
      } catch (err: any) {
        if (!err.toString().includes("Cancelled") && !err.toString().includes("Interrupted")) {
          alert("Upload failed: " + err.toString());
        }
      } finally {
        setUploadProgress(null);
        setUploading(false);
        await loadObjects();
        useAppStore.getState().setR2Buckets([]);
      }
    } catch (err: any) {
      if (!uploading) alert("Upload setup failed: " + err.toString());
    }
  };

  const handleCancelUpload = async () => {
    if (uploadProgress) {
      await cancelUploadR2Object(uploadProgress.id, uploadProgress.bucketName, uploadProgress.key);
      setUploadProgress(null);
      setUploading(false);
    }
  };

  const handleDelete = async (key: string) => {
    try {
      setLoading(true);
      setConfirmDeleteKey(null);
      await deleteR2Object(bucket.name, key);
      await loadObjects();
      useAppStore.getState().setR2Buckets([]);
    } catch (err: any) {
      alert("Delete failed: " + err.toString());
      setLoading(false);
    }
  };

  const handleDownload = async (file: R2Object) => {
    if (!downloadGate.isAvailable) { downloadGate.showProToast(); return; }
    try {
      const filename = file.key.split('/').pop() || "download";
      const savePath = await saveDialog({
        defaultPath: filename,
        title: "Save File As",
      });

      if (!savePath) return;

      await downloadR2Object(bucket.name, file.key, savePath);
    } catch (err: any) {
      alert("Download failed: " + err.toString());
    }
  };

  const handleShare = (file: R2Object) => {
    if (!publicUrl) return;
    const directUrl = `${publicUrl}/${file.key}`;
    navigator.clipboard.writeText(directUrl).then(() => {
      toast({
        title: "Link Copied",
        description: "Public direct URL copied to clipboard.",
      });
    }).catch(err => alert("Failed to copy link: " + err));
  };

  const breadcrumbs = useMemo(() => {
    const parts = prefix.split('/').filter(Boolean);
    return parts;
  }, [prefix]);

  const handleArrowBack = () => {
    if (prefix === "") {
      onBack();
    } else {
      const parts = prefix.split('/').filter(Boolean);
      parts.pop();
      const newPrefix = parts.length > 0 ? parts.join('/') + '/' : '';
      setPrefix(newPrefix);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background relative">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0 bg-muted/10">
        <div className="flex flex-col gap-1.5 min-w-0">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <button
              onClick={handleArrowBack}
              className="hover:text-foreground transition-colors p-1 -ml-1 rounded-md hover:bg-muted"
            >
              <ArrowLeft size={14} />
            </button>
            <span className={cn("font-medium text-foreground", blurBucket && "blur-[4px] hover:blur-none transition-all duration-200 select-none hover:select-auto cursor-default")}>{bucket.name}</span>
            {publicUrl === undefined ? (
               <div className="w-12 h-4 rounded bg-muted animate-pulse shrink-0 ml-1" />
            ) : publicUrl ? (
               <Badge variant="outline" className="text-[10px] h-5 gap-1 font-normal border-green-500/30 text-green-600 bg-green-500/5 cursor-pointer hover:bg-green-500/10 shrink-0 ml-1" title={publicUrl} onClick={() => {
                 navigator.clipboard.writeText(publicUrl);
                 toast({ title: "Copied!", description: "Bucket base URL copied."});
               }}>
                 <Globe size={10} className="text-green-500" />
                 Public
               </Badge>
            ) : (
               <Badge variant="outline" className="text-[10px] h-5 gap-1 font-normal text-muted-foreground shrink-0 ml-1">
                 <Lock size={10} />
                 Private
               </Badge>
            )}
            {/* Settings button — gated via remote config */}
            <div className="relative inline-flex items-center ml-1">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted" 
                onClick={() => {
                  if (settingsGate.isAvailable) {
                    setShowSettingsModal(true);
                  } else {
                    settingsGate.showProToast();
                  }
                }} 
                title={settingsGate.isAvailable ? "Public Access Settings" : "Unlock Public Access Settings"}
              >
                <Settings size={14} />
              </Button>
              {!settingsGate.isAvailable && (
                <span className="absolute -top-1 -right-2 bg-orange-500 text-[8px] font-bold px-1 rounded-[4px] text-white shadow-sm pointer-events-none z-10">PRO</span>
              )}
            </div>
          </div>

          {/* Breadcrumbs */}
          <div className="flex items-center gap-1 text-xs text-muted-foreground overflow-x-auto no-scrollbar">
            <button
              onClick={() => setPrefix("")}
              className={cn("hover:text-foreground transition-colors", prefix === "" ? "text-foreground font-medium" : "")}
            >
              root
            </button>
            {breadcrumbs.map((part, i) => (
              <div key={i} className="flex items-center gap-1">
                <ChevronRight size={12} className="text-muted-foreground/40" />
                <button
                  onClick={() => handleBreadcrumbClick(i)}
                  className={cn(
                    "hover:text-foreground transition-colors truncate max-w-[150px]",
                    i === breadcrumbs.length - 1 ? "text-foreground font-medium" : ""
                  )}
                >
                  {part}
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadObjects()}
            disabled={loading}
          >
            <RefreshCw size={14} className={cn("mr-2", loading && "animate-spin")} />
            Refresh
          </Button>
          {/* Upload File — gated via remote config */}
          <R2ProGate featureName="r2_upload">
            <Button size="sm" onClick={() => setShowUploadModal(true)} disabled={uploading}>
              <UploadCloud size={14} className="mr-2" />
              {uploading ? "Uploading..." : "Upload File"}
            </Button>
          </R2ProGate>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="w-[45%] text-xs font-medium uppercase text-muted-foreground">Name</TableHead>
                <TableHead className="text-xs font-medium uppercase text-muted-foreground">Size</TableHead>
                <TableHead className="text-xs font-medium uppercase text-muted-foreground">Uploaded At</TableHead>
                <TableHead className="w-24 text-right"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {/* Folders */}
              {listing?.folders.map((folderPrefix) => {
                const display = folderPrefix.slice(prefix.length).replace(/\/$/, "");
                return (
                  <TableRow key={folderPrefix} className="hover:bg-accent/40 cursor-pointer" onClick={() => handleNavigate(folderPrefix)}>
                    <TableCell className="font-medium py-3">
                      <div className="flex items-center gap-2.5">
                        <Folder size={14} className="text-blue-500 fill-blue-500/20" />
                        <span className={cn("truncate", blurFile && "blur-[4px] hover:blur-none transition-all duration-200 select-none hover:select-auto cursor-default")}>{display}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs py-3">—</TableCell>
                    <TableCell className="text-muted-foreground text-xs py-3">—</TableCell>
                    <TableCell className="py-3 text-right"></TableCell>
                  </TableRow>
                );
              })}

              {/* Files */}
              {listing?.files.map((file) => {
                const display = file.key.slice(prefix.length);
                return (
                  <TableRow key={file.key} className="hover:bg-accent/40">
                    <TableCell className="font-medium py-3">
                      <div className="flex items-center gap-2.5">
                        {getFileIcon(file.key)}
                        <span className={cn("truncate", blurFile && "blur-[4px] hover:blur-none transition-all duration-200 select-none hover:select-auto cursor-default")}>{display}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs py-3">{formatBytes(file.size)}</TableCell>
                    <TableCell className="text-muted-foreground text-xs py-3">{formatDate(file.uploaded)}</TableCell>
                    <TableCell className="py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        {publicUrl && (
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => handleShare(file)} title="Copy Public URL">
                            <LinkIcon size={13} />
                          </Button>
                        )}
                        {/* Download — gated via remote config */}
                        <R2ProGate featureName="r2_download" inline>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => handleDownload(file)}>
                            <Download size={13} />
                          </Button>
                        </R2ProGate>
                        {/* Delete — always public */}
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive/70 hover:text-destructive hover:bg-destructive/10" onClick={() => setConfirmDeleteKey(file.key)}>
                          <Trash2 size={13} />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}

              {/* Empty state */}
              {!loading && listing?.files.length === 0 && listing?.folders.length === 0 && (
                <TableRow className="hover:bg-transparent">
                  <TableCell colSpan={4} className="py-12 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <File size={24} className="opacity-20 mb-2" />
                      <p className="text-sm">This folder is empty</p>
                      <p className="text-xs opacity-70">Click "Upload File" to add objects securely to your R2 bucket</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      
      {showPurchaseScreen && <PurchaseScreen onClose={() => setShowPurchaseScreen(false)} />}
      
      {/* Upload Progress Dialog */}
      <Dialog open={!!uploadProgress} onOpenChange={(open) => {
        if (!open && uploadProgress) handleCancelUpload();
      }}>
        <DialogContent 
           className="sm:max-w-md [&>button]:hidden" 
           onInteractOutside={(e) => e.preventDefault()} 
           onEscapeKeyDown={(e) => e.preventDefault()}
        >
          <DialogHeader>
            <DialogTitle>Uploading File...</DialogTitle>
            <DialogDescription className="truncate">
              {uploadProgress?.key}
            </DialogDescription>
          </DialogHeader>
          <div className="py-2">
             <div className="flex justify-between text-sm mb-1 text-muted-foreground font-mono">
               <span>{formatBytes(uploadProgress?.bytes)} / {formatBytes(uploadProgress?.total)}</span>
               <span>{formatBytes(uploadProgress?.speedBps)}/s</span>
             </div>
             <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
               <div 
                 className="h-full bg-primary transition-all duration-300 ease-out" 
                 style={{ width: `${Math.min(100, ((uploadProgress?.bytes || 0) / (uploadProgress?.total || 1)) * 100)}%` }} 
               />
             </div>
          </div>
          <div className="flex justify-end mt-2">
            <Button variant="outline" onClick={handleCancelUpload}>Cancel Upload</Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {showSettingsModal && (
        <R2BucketSettingsModal 
          bucketName={bucket.name} 
          onClose={() => setShowSettingsModal(false)} 
          onUpdate={fetchDomain} 
        />
      )}

      <R2UploadModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        maxUploadSize={config?.max_r2_upload_size}
        onUpload={handleConfirmUpload}
      />

      {/* Confirm Delete File Dialog */}
      <AlertDialog open={!!confirmDeleteKey} onOpenChange={(open) => !open && setConfirmDeleteKey(null)}>
        <AlertDialogContent className="max-w-md border-border/60 shadow-2xl">
          <AlertDialogHeader>
            <AlertTitle>Delete File?</AlertTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <span className="font-mono font-medium text-xs">{confirmDeleteKey?.split('/').pop()}</span>? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => confirmDeleteKey && handleDelete(confirmDeleteKey)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
