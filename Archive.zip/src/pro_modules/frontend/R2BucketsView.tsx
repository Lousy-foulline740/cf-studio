// R2BucketsView.tsx
//
// R2 Buckets listing page — auto-fetches from the Cloudflare API.
// Clicking a row drills into R2Explorer for file management.
//
// Pro features (New Bucket, Delete Bucket, Settings) are gated via
// the remote config at pro.cfstudio.dev/config.json.

import { useState, useEffect } from "react";
import { RefreshCw, Box, Terminal, AlertCircle, Globe, Lock, MoreVertical, Settings, Trash2, Plus } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { type R2Bucket, getR2BucketDomain } from "@/lib/r2";
import { useR2Buckets, invokeCloudflare } from "@/hooks/useCloudflare";
import { R2Explorer } from "./R2Explorer";
import { R2CreateBucketModal } from "./R2CreateBucketModal";
import { R2DeleteBucketModal } from "./R2DeleteBucketModal";
import { useAppStore } from "@/store/useAppStore";
import { open as openUrl } from "@tauri-apps/plugin-shell";
import { cn } from "@/lib/utils";
import { R2BucketSettingsModal } from "./R2BucketSettingsModal";
import { R2ProGate, useProFeature } from "@/components/R2ProGate";

function formatDate(iso?: string): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(iso));
}

function formatBytes(bytes?: number): string {
  if (bytes === undefined) return "—";
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

// ── Components ─────────────────────────────────────────────────────────────────

function LoadingSkeleton() {
  return (
    <div className="w-full space-y-0 rounded-lg border border-border overflow-hidden">
      <div className="grid grid-cols-3 border-b border-border bg-muted/40 px-4 py-2.5">
        <div className="h-3.5 w-16 rounded bg-muted animate-pulse" />
      </div>
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="grid grid-cols-3 border-b border-border px-4 py-3.5 last:border-0">
          <div className="h-3.5 w-32 rounded bg-muted/60 animate-pulse" />
        </div>
      ))}
    </div>
  );
}

function EmptyState({ variant, message, onRefresh, accountId }: { variant: "no-auth" | "no-buckets" | "api-error" | "not-enabled", message?: string, onRefresh: () => void, accountId?: string | null }) {
  const handleCopyCommand = async () => {
    try {
      await navigator.clipboard.writeText("npx wrangler login");
    } catch (e) {
      console.error(e);
    }
  };

  const handleRunCommand = async () => {
    try {
      await invokeCloudflare("run_wrangler_login");
    } catch (e) {
      console.error(e);
    }
  };

  const configs = {
    "no-auth": {
      icon: Terminal,
      iconColor: "text-amber-400",
      title: "Wrangler session not found",
      body: (
        <>
          CF Studio reads your local Wrangler session for zero-touch auth.
          Run the command below in your terminal or click the button below. 
          The page will automatically refresh once you are logged in.
          <div className="mt-3 flex items-center justify-between gap-2 rounded-md border border-border bg-muted/60 px-3 py-2 font-mono text-sm text-foreground">
            <span className="select-text">npx wrangler login</span>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleCopyCommand} title="Copy command">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
            </Button>
          </div>
          <Button variant="secondary" size="sm" className="w-full mt-3" onClick={handleRunCommand}>
            <Terminal size={14} className="mr-2" />
            Run Command in Background
          </Button>
        </>
      ),
    },
    "no-buckets": {
      icon: Box,
      iconColor: "text-muted-foreground",
      title: "No R2 buckets found",
      body: (
        <>
          This Cloudflare account has no R2 buckets yet. Create one with:
          <div className="mt-3 flex items-center gap-2 rounded-md border border-border bg-muted/60 px-3 py-2 font-mono text-sm text-foreground">
            <span className="select-text">wrangler r2 bucket create my-bucket</span>
          </div>
        </>
      ),
    },
    "not-enabled": {
      icon: Box,
      iconColor: "text-blue-500",
      title: "R2 Storage Not Enabled",
      body: (
        <>
          It looks like Cloudflare R2 object storage is not yet enabled for this account. You must enable it in the dashboard before managing buckets.
          <div className="mt-5 flex items-center justify-center">
            <Button
              onClick={() => {
                if (accountId) openUrl(`https://dash.cloudflare.com/${accountId}/r2/overview`);
              }}
              size="sm"
            >
              Enable R2 Storage
            </Button>
          </div>
        </>
      ),
    },
    "api-error": {
      icon: AlertCircle,
      iconColor: "text-destructive",
      title: "Failed to load buckets",
      body: <p className="text-sm text-muted-foreground">{message}</p>,
    },
  };

  const { icon: Icon, iconColor, title, body } = configs[variant];

  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[320px] text-center gap-5 px-6">
      <div className={cn("rounded-xl border border-border bg-muted/30 p-4", iconColor)}>
        <Icon size={28} strokeWidth={1.5} />
      </div>
      <div className="max-w-sm space-y-2">
        <h2 className="text-base font-semibold text-foreground">{title}</h2>
        <div className="text-sm text-muted-foreground leading-relaxed text-left">{body}</div>
      </div>
      <Button variant="outline" size="sm" onClick={onRefresh} className="gap-1.5 mt-1">
        <RefreshCw size={13} strokeWidth={2} />
        Refresh
      </Button>
    </div>
  );
}

// ── Main View ─────────────────────────────────────────────────────────────────

function BucketList({ onSelect }: { onSelect: (b: R2Bucket) => void }) {
  const { state, refresh } = useR2Buckets();
  const activeAccount = useAppStore((s) => s.activeAccount);
  const privacySettings = useAppStore((s) => s.privacySettings);
  const blurBucket = privacySettings.enabled && privacySettings.r2BucketNames;
  const isLoading = state.status === "loading" || state.status === "idle";
  const [domainCache, setDomainCache] = useState<Record<string, string | null>>({});
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [settingsBucketName, setSettingsBucketName] = useState<string | null>(null);
  const [deletingBucketName, setDeletingBucketName] = useState<string | null>(null);

  // Pro feature gate hooks (imperative — for dropdown menu items)
  const deleteBucketGate = useProFeature("r2_delete_bucket");
  const settingsGate = useProFeature("r2_bucket_settings");

  useEffect(() => {
    if (state.status === "success") {
      state.data.forEach((bucket) => {
        if (domainCache[bucket.name] === undefined) {
          getR2BucketDomain(bucket.name).then((domain) => {
            setDomainCache(prev => ({ ...prev, [bucket.name]: domain }));
          }).catch(() => {
            setDomainCache(prev => ({ ...prev, [bucket.name]: null }));
          });
        }
      });
    }
  }, [state, domainCache]);

  return (
    <div className="flex flex-col gap-5 h-full">
      <div className="flex items-center justify-between gap-4 shrink-0">
        <div>
          <h1 className="text-lg font-semibold tracking-tight text-foreground">R2 Buckets</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Object storage attached to your Cloudflare account
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* New Bucket — gated via remote config */}
          <R2ProGate featureName="r2_create_bucket">
            <Button onClick={() => setShowCreateModal(true)} size="sm">
              <Plus size={14} className="mr-2" />
              New Bucket
            </Button>
          </R2ProGate>
          <Button
            variant="ghost"
            size="icon"
            onClick={refresh}
            disabled={isLoading}
            className="text-muted-foreground hover:text-foreground"
          >
            <RefreshCw size={14} strokeWidth={2} className={cn(isLoading && "animate-spin")} />
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        {isLoading && <LoadingSkeleton />}
        {state.status === "error" && state.message.toLowerCase().includes("10042") && (
          <EmptyState variant="not-enabled" accountId={activeAccount?.id} onRefresh={refresh} />
        )}
        {state.status === "error" && !state.message.toLowerCase().includes("10042") && state.message.toLowerCase().includes("wrangler") && (
          <EmptyState variant="no-auth" message={state.message} onRefresh={refresh} />
        )}
        {state.status === "error" && !state.message.toLowerCase().includes("10042") && !state.message.toLowerCase().includes("wrangler") && (
          <EmptyState variant="api-error" message={state.message} onRefresh={refresh} />
        )}
        {state.status === "success" && state.data.length === 0 && (
          <EmptyState variant="no-buckets" onRefresh={refresh} />
        )}
        {state.status === "success" && state.data.length > 0 && (
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30 hover:bg-muted/30">
                  <TableHead className="text-xs font-medium uppercase tracking-wider text-muted-foreground py-2.5">Name</TableHead>
                  <TableHead className="text-xs font-medium uppercase tracking-wider text-muted-foreground py-2.5">Objects</TableHead>
                  <TableHead className="text-xs font-medium uppercase tracking-wider text-muted-foreground py-2.5">Size</TableHead>
                  <TableHead className="text-xs font-medium uppercase tracking-wider text-muted-foreground py-2.5">Created At</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {state.data.map((bucket) => (
                  <TableRow
                    key={bucket.name}
                    onClick={() => onSelect(bucket)}
                    className="group cursor-pointer hover:bg-accent/40 transition-colors"
                  >
                    <TableCell className="font-medium text-foreground py-3.5">
                      <div className="flex items-center gap-2">
                        <Box size={13} strokeWidth={1.75} className="text-primary shrink-0" />
                        <span className={cn(
                          "truncate",
                          blurBucket && "blur-[4px] hover:blur-none transition-all duration-200 select-none hover:select-auto cursor-default"
                        )}>
                          {bucket.name}
                        </span>
                        {domainCache[bucket.name] === undefined ? (
                          <div className="w-12 h-4 rounded bg-muted animate-pulse shrink-0 ml-1" />
                        ) : domainCache[bucket.name] ? (
                           <Badge variant="outline" className="text-[10px] h-5 gap-1 font-normal border-green-500/30 text-green-600 bg-green-500/5 hover:bg-green-500/10 shrink-0 ml-1" title={domainCache[bucket.name]!}>
                             <Globe size={10} className="text-green-500" />
                             Public
                           </Badge>
                        ) : (
                           <Badge variant="outline" className="text-[10px] h-5 gap-1 font-normal text-muted-foreground shrink-0 ml-1">
                             <Lock size={10} />
                             Private
                           </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground py-3.5">
                      {bucket.object_count ?? "—"}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground py-3.5">
                      {formatBytes(bucket.total_size_bytes)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground py-3.5">
                      {formatDate(bucket.creation_date)}
                    </TableCell>
                    <TableCell className="w-10 pr-4 text-right align-middle" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 hover:bg-muted text-muted-foreground/60 transition-colors">
                            <span className="sr-only">Open menu</span>
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {/* Settings — gated via remote config */}
                          <DropdownMenuItem onClick={() => {
                            if (settingsGate.isAvailable) {
                              setSettingsBucketName(bucket.name);
                            } else {
                              settingsGate.showProToast();
                            }
                          }} className="cursor-pointer font-medium relative pr-8">
                            <Settings className="mr-2 h-4 w-4 text-muted-foreground" />
                            <span>Settings</span>
                            {!settingsGate.isAvailable && (
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 bg-orange-500 text-[8px] font-bold px-1 rounded-[4px] text-white shadow-sm pointer-events-none">PRO</span>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {/* Delete Bucket — gated via remote config */}
                          <DropdownMenuItem onSelect={(e) => {
                            e.preventDefault();
                            if (deleteBucketGate.isAvailable) {
                              setDeletingBucketName(bucket.name);
                            } else {
                              deleteBucketGate.showProToast();
                            }
                          }} className="cursor-pointer font-medium relative pr-8">
                            <Trash2 className="mr-2 h-4 w-4 text-destructive/70" />
                            <span className={!deleteBucketGate.isAvailable ? "text-muted-foreground" : "text-destructive"}>Delete Bucket</span>
                            {!deleteBucketGate.isAvailable && (
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 bg-orange-500 text-[8px] font-bold px-1 rounded-[4px] text-white shadow-sm pointer-events-none">PRO</span>
                            )}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <R2CreateBucketModal 
        isOpen={showCreateModal} 
        onClose={() => setShowCreateModal(false)}
        existingBuckets={state.status === "success" ? state.data : []}
        onCreated={refresh}
      />

      {settingsBucketName && (
        <R2BucketSettingsModal 
          bucketName={settingsBucketName} 
          onClose={() => setSettingsBucketName(null)}
          onUpdate={() => {
            getR2BucketDomain(settingsBucketName).then((domain) => {
              setDomainCache(prev => ({ ...prev, [settingsBucketName]: domain }));
            }).catch(() => {
              setDomainCache(prev => ({ ...prev, [settingsBucketName]: null }));
            });
          }} 
        />
      )}

      {deletingBucketName && (
        <R2DeleteBucketModal
          bucketName={deletingBucketName}
          isOpen={true}
          onClose={() => setDeletingBucketName(null)}
          onDeleted={refresh}
        />
      )}
    </div>
  );
}

export function R2BucketsView() {
  const [selectedBucket, setSelectedBucket] = useState<R2Bucket | null>(null);

  if (selectedBucket) {
    return <R2Explorer bucket={selectedBucket} onBack={() => setSelectedBucket(null)} />;
  }

  return <BucketList onSelect={setSelectedBucket} />;
}
