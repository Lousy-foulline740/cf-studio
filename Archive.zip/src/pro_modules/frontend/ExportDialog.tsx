import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { save } from '@tauri-apps/plugin-dialog';
import { writeTextFile } from '@tauri-apps/plugin-fs';
import { useToast } from '@/components/ui/use-toast';
import { jsonToCsv } from './exportUtils';

export interface ExportDialogProps {
  isOpen?: boolean;
  onClose?: () => void;
  dataToExport?: any[];
  allColumns?: string[];
}

export function ExportDialog({ isOpen = false, onClose, dataToExport = [], allColumns = [] }: ExportDialogProps) {
  const { toast } = useToast();
  const [format, setFormat] = useState<'csv' | 'json'>('csv');
  const [selectedColumns, setSelectedColumns] = useState<Set<string>>(new Set());
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Initialize selected columns to all columns when the dialog opens
  useEffect(() => {
    if (isOpen) {
      setSelectedColumns(new Set(allColumns));
    }
  }, [allColumns, isOpen]);

  const handleToggleColumn = (col: string) => {
    const next = new Set(selectedColumns);
    if (next.has(col)) {
      next.delete(col);
    } else {
      next.add(col);
    }
    setSelectedColumns(next);
  };

  const handleExport = async () => {
    if (selectedColumns.size === 0) {
      toast({
        title: "No columns selected",
        description: "Please select at least one column to export.",
        variant: "destructive",
      });
      return;
    }

    // Console logging the format and selected columns for debugging purposes


    setIsExporting(true);
    try {
      // Filter the data payload down to only the selected columns
      const filteredData = dataToExport.map((row) => {
        const newRow: Record<string, any> = {};
        for (const col of Array.from(selectedColumns)) {
          if (row.hasOwnProperty(col)) {
            newRow[col] = row[col];
          }
        }
        return newRow;
      });

      // Format data based on selected type
      const fileData = format === 'csv' ? jsonToCsv(filteredData) : JSON.stringify(filteredData, null, 2);

      // Trigger native save prompt via Tauri
      const savePath = await save({
        defaultPath: `export_${Date.now()}.${format}`,
        filters: [{
          name: format === 'csv' ? 'CSV Document' : 'JSON Document',
          extensions: [format]
        }]
      });

      // If the user didn't cancel the dialog, save the file
      if (savePath) {
        await writeTextFile(savePath, fileData);
        toast({
          title: "Export Successful",
          description: `Data successfully exported to ${savePath}.`,
        });
        if (onClose) onClose();
      }
    } catch (error) {
      console.error("Export error:", error);
      toast({
        title: "Export Failed",
        description: "An error occurred while exporting the data.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open: boolean) => { if (!open && onClose) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Export Data</DialogTitle>
          <DialogDescription>
            Choose your format and customize columns for the export.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-4">
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium w-1/4">Format</span>
            <Select value={format} onValueChange={(val: 'csv' | 'json') => setFormat(val)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV (.csv)</SelectItem>
                <SelectItem value="json">JSON (.json)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Collapsible
            open={isAdvancedOpen}
            onOpenChange={setIsAdvancedOpen}
            className="w-full space-y-2 border rounded-md p-3"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold">Advanced Options</h4>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="sm" className="w-9 p-0">
                  <span className="sr-only">Toggle</span>
                  {isAdvancedOpen ? '▲' : '▼'}
                </Button>
              </CollapsibleTrigger>
            </div>
            <CollapsibleContent className="space-y-2 mt-2 max-h-48 overflow-y-auto pr-2">
              {allColumns.map((col) => (
                <div key={col} className="flex items-center space-x-2">
                  <Checkbox
                    id={`col-${col}`}
                    checked={selectedColumns.has(col)}
                    onCheckedChange={() => handleToggleColumn(col)}
                  />
                  <label
                    htmlFor={`col-${col}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {col}
                  </label>
                </div>
              ))}
            </CollapsibleContent>
          </Collapsible>
        </div>

        <DialogFooter className="sm:justify-end">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" onClick={handleExport} disabled={isExporting}>
            {isExporting ? 'Exporting...' : 'Export'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
