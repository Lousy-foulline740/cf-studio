import { Loader2 } from "lucide-react";
import { useRemoteConfig } from "./useRemoteConfig";
import { ExportDialog } from "./ExportDialog";
import { PurchaseScreen } from "./PurchaseScreen";

import { Dialog, DialogContent } from "@/components/ui/dialog";

export interface ProFeatureGateProps {
  isOpen?: boolean;
  onClose?: () => void;
  dataToExport?: any[];
  allColumns?: string[];
}

export function ProFeatureGate({ isOpen = false, onClose, dataToExport = [], allColumns = [] }: ProFeatureGateProps) {
  const { data, isLoading, error } = useRemoteConfig();
  const hasLicense = false; // Dummy state for testing



  if (!isOpen) {
    return (
      <ExportDialog 
        isOpen={false} 
        onClose={onClose} 
        dataToExport={dataToExport} 
        allColumns={allColumns} 
      />
    );
  }

  if (isLoading) {
    return (
      <Dialog open={isOpen} onOpenChange={(o) => { if (!o && onClose) onClose(); }}>
        <DialogContent className="sm:max-w-md flex items-center justify-center py-10">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </DialogContent>
      </Dialog>
    );
  }

  if (error) {
    return (
      <Dialog open={isOpen} onOpenChange={(o) => { if (!o && onClose) onClose(); }}>
        <DialogContent className="sm:max-w-md text-center py-10 text-red-500">
          Error loading config: {error.message}
        </DialogContent>
      </Dialog>
    );
  }

  if (data && data.is_export_free === false && !hasLicense) {
    return <PurchaseScreen onClose={onClose} />;
  }

  return (
    <ExportDialog 
      isOpen={isOpen} 
      onClose={onClose} 
      dataToExport={dataToExport} 
      allColumns={allColumns} 
    />
  );
}
