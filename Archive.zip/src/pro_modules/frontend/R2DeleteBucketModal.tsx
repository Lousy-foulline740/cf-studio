import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, AlertTriangle } from "lucide-react";
import { emptyR2Bucket, deleteR2Bucket } from "@/lib/r2";
import { useToast } from "@/components/ui/use-toast";
import { listen } from "@tauri-apps/api/event";

export function R2DeleteBucketModal({
  bucketName,
  isOpen,
  onClose,
  onDeleted
}: {
  bucketName: string;
  isOpen: boolean;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const [confirmText, setConfirmText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [progress, setProgress] = useState<{ deleted: number; total: number } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!isOpen) {
      setConfirmText("");
      setProgress(null);
      setIsDeleting(false);
    }
  }, [isOpen]);

  useEffect(() => {
    let unlisten: () => void;
    if (isDeleting) {
      listen<any>("empty-bucket-progress", (event) => {
        if (event.payload.bucket_name === bucketName) {
          setProgress({ deleted: event.payload.deleted, total: event.payload.total });
        }
      }).then(un => { unlisten = un; });
    }
    return () => {
      if (unlisten) unlisten();
    };
  }, [isDeleting, bucketName]);

  const handleDelete = async () => {
    if (confirmText !== bucketName) return;
    setIsDeleting(true);
    setProgress({ deleted: 0, total: 0 });

    try {
      // 1. Empty the bucket first
      await emptyR2Bucket(bucketName);
      
      // 2. Delete the actual bucket
      await deleteR2Bucket(bucketName);
      
      toast({ title: "Bucket Deleted", description: `Successfully deleted ${bucketName} and its contents.` });
      onDeleted();
      onClose();
    } catch (err: any) {
      toast({ variant: "destructive", title: "Failed to delete bucket", description: err.toString() });
      setIsDeleting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!isDeleting && !open) onClose();
    }}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Delete Bucket
          </DialogTitle>
          <DialogDescription>
            This will permanently delete the bucket <strong className="break-all">{bucketName}</strong> and all of its contents. This action cannot be undone.
          </DialogDescription>
        </DialogHeader>

        {!isDeleting ? (
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground block">
                To confirm, type <span className="font-mono text-foreground font-bold select-all">{bucketName}</span> below:
              </label>
              <Input
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder={bucketName}
                className="font-mono text-sm"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && confirmText === bucketName) {
                    handleDelete();
                  }
                }}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button 
                variant="destructive" 
                onClick={handleDelete}
                disabled={confirmText !== bucketName}
              >
                Delete Everything
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="py-6 flex flex-col items-center justify-center space-y-4">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            <div className="text-center space-y-1">
              <h4 className="text-sm font-medium text-foreground">Deleting Bucket Contents</h4>
              {progress ? (
                <p className="text-sm text-muted-foreground flex items-center gap-1 justify-center">
                  {progress.total > 0 
                    ? <span>Deleted <strong>{progress.deleted}</strong> of <strong>{progress.total}</strong> objects...</span>
                    : <span>Emptying...</span>}
                </p>
              ) : (
                <p className="text-sm text-muted-foreground">Initializing deletion...</p>
              )}
            </div>
            {progress && progress.total > 0 && (
              <div className="w-full h-2 bg-secondary rounded-full overflow-hidden mt-4">
                <div 
                  className="h-full bg-destructive transition-all duration-300 ease-out"
                  style={{ width: `${Math.max(5, (progress.deleted / progress.total) * 100)}%` }}
                />
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
