import React, { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Plus, Globe, Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { 
  BucketDomainsInfo, 
  CfZone,
  getR2BucketDomainsList, 
  updateR2BucketManagedDomain, 
  addR2BucketCustomDomain, 
  removeR2BucketCustomDomain,
  fetchCloudflareZones
} from "@/lib/r2";

interface Props {
  bucketName: string;
  onClose: () => void;
  onUpdate: () => void;
}

/**
 * Given a domain like "cdn.assets.example.com", find the matching zone
 * from the user's Cloudflare account by walking up the domain tree:
 *   cdn.assets.example.com → assets.example.com → example.com
 */
function findMatchingZone(domain: string, zones: CfZone[]): CfZone | null {
  const parts = domain.split(".");
  // Walk from the full domain up to the TLD+1
  for (let i = 0; i < parts.length - 1; i++) {
    const candidate = parts.slice(i).join(".");
    const zone = zones.find((z) => z.name === candidate);
    if (zone) return zone;
  }
  return null;
}

export function R2BucketSettingsModal({ bucketName, onClose, onUpdate }: Props) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [domains, setDomains] = useState<BucketDomainsInfo | null>(null);
  
  const [newDomain, setNewDomain] = useState("");
  const [addingDomain, setAddingDomain] = useState(false);
  
  const [togglingManaged, setTogglingManaged] = useState(false);
  const [removingDomain, setRemovingDomain] = useState<string | null>(null);
  const [confirmRemoveDomain, setConfirmRemoveDomain] = useState<string | null>(null);

  // Zones state — fetched once when modal opens
  const [zones, setZones] = useState<CfZone[]>([]);
  const [zonesLoading, setZonesLoading] = useState(true);
  const [zonesError, setZonesError] = useState<string | null>(null);

  // Auto-resolved zone for the entered domain
  const resolvedZone = useMemo(() => {
    if (!newDomain.trim() || zones.length === 0) return null;
    return findMatchingZone(newDomain.trim().toLowerCase(), zones);
  }, [newDomain, zones]);

  const fetchDomains = async () => {
    try {
      setLoading(true);
      const data = await getR2BucketDomainsList(bucketName);
      setDomains(data);
    } catch (err: any) {
      toast({ variant: "destructive", title: "Failed to fetch domains", description: err.toString() });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDomains();
    // Fetch zones in parallel
    fetchCloudflareZones()
      .then((z) => { setZones(z); setZonesLoading(false); })
      .catch((err) => { setZonesError(err.toString()); setZonesLoading(false); });
  }, [bucketName]);

  const handleToggleManaged = async (checked: boolean) => {
    try {
      setTogglingManaged(true);
      await updateR2BucketManagedDomain(bucketName, checked);
      toast({ title: "Updated Managed Domain", description: `The r2.dev domain has been ${checked ? 'enabled' : 'disabled'}.` });
      await fetchDomains();
      onUpdate();
    } catch (err: any) {
      toast({ variant: "destructive", title: "Failed to update managed domain", description: err.toString() });
    } finally {
      setTogglingManaged(false);
    }
  };

  const handleAddDomain = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim() || !resolvedZone) return;

    try {
      setAddingDomain(true);
      await addR2BucketCustomDomain(bucketName, newDomain.trim(), resolvedZone.id, resolvedZone.name);
      toast({ title: "Domain Connected", description: `Successfully connected ${newDomain.trim()} to this bucket.` });
      setNewDomain("");
      await fetchDomains();
      onUpdate();
    } catch (err: any) {
      toast({ variant: "destructive", title: "Failed to add domain", description: err.toString() });
    } finally {
      setAddingDomain(false);
    }
  };

  const handleRemoveDomain = async (domain: string) => {
    try {
      setRemovingDomain(domain);
      await removeR2BucketCustomDomain(bucketName, domain);
      toast({ title: "Domain Removed", description: `Successfully disconnected ${domain}.` });
      await fetchDomains();
      onUpdate();
    } catch (err: any) {
      toast({ variant: "destructive", title: "Failed to remove domain", description: err.toString() });
    } finally {
      setRemovingDomain(null);
      setConfirmRemoveDomain(null);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-muted-foreground" />
            Public Access Settings
            {loading && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground ml-2" />}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Managed Domain Section */}
          <div className="flex flex-col gap-2 p-4 bg-muted/30 rounded-lg border border-border">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-medium">Cloudflare Managed Subdomain</Label>
                <p className="text-sm text-muted-foreground">Allow public access via `.r2.dev`</p>
              </div>
              <Switch 
                checked={domains?.managed?.enabled || false}
                onCheckedChange={handleToggleManaged}
                disabled={loading || togglingManaged}
              />
            </div>
            {domains?.managed?.enabled && domains?.managed?.domain && (
              <div className="bg-background mt-2 px-3 py-2 rounded text-xs text-muted-foreground font-mono truncate">
                https://{domains.managed.domain}
              </div>
            )}
            {togglingManaged && <p className="text-xs text-muted-foreground animate-pulse mt-1">Applying changes...</p>}
          </div>

          {/* Custom Domains Section */}
          <div className="space-y-3">
            <div>
              <Label className="text-base font-medium">Custom Domains</Label>
              <p className="text-sm text-muted-foreground">Connect your own domains (must be in your Cloudflare account).</p>
            </div>

            <div className="space-y-2">
              {domains?.custom && domains.custom.length > 0 ? (
                domains.custom.map((d: any) => (
                  <div key={d.domain} className="flex items-center justify-between bg-muted/20 border border-border px-3 py-2 rounded-md">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium flex items-center gap-2">
                        {d.domain}
                        {d.enabled ? (
                           <span className="w-2 h-2 rounded-full bg-green-500" title="Active"></span>
                        ) : (
                           <span className="w-2 h-2 rounded-full bg-yellow-500" title="Pending"></span>
                        )}
                      </span>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-destructive/70 hover:text-destructive hover:bg-destructive/10"
                      onClick={() => setConfirmRemoveDomain(d.domain)}
                      disabled={removingDomain === d.domain}
                    >
                      {removingDomain === d.domain ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                    </Button>
                  </div>
                ))
              ) : (
                !loading && <div className="text-sm text-muted-foreground italic border border-dashed rounded-md p-4 text-center">No custom domains connected yet.</div>
              )}
            </div>

            <form onSubmit={handleAddDomain} className="mt-4 p-4 border rounded-lg bg-muted/10 space-y-3">
              <div className="space-y-2 flex-col">
                 <Label>Connect a Custom Domain</Label>
                 <Input 
                   placeholder="e.g. cdn.yourdomain.com"
                   value={newDomain}
                   onChange={e => setNewDomain(e.target.value)}
                   disabled={addingDomain}
                   required
                 />

                 {/* Zone auto-resolution status */}
                 {newDomain.trim() && (
                   <div className="text-xs mt-1.5">
                     {zonesLoading ? (
                       <span className="text-muted-foreground flex items-center gap-1.5">
                         <Loader2 className="w-3 h-3 animate-spin" />
                         Loading zones...
                       </span>
                     ) : zonesError ? (
                       <span className="text-destructive flex items-center gap-1.5">
                         <AlertTriangle className="w-3 h-3" />
                         Failed to load zones
                       </span>
                     ) : resolvedZone ? (
                       <span className="text-green-600 flex items-center gap-1.5">
                         <CheckCircle2 className="w-3 h-3" />
                         Zone matched: <span className="font-mono font-medium">{resolvedZone.name}</span>
                       </span>
                     ) : (
                       <span className="text-amber-500 flex items-center gap-1.5">
                         <AlertTriangle className="w-3 h-3" />
                         No matching zone found — make sure this domain is added to your Cloudflare account.
                       </span>
                     )}
                   </div>
                 )}
              </div>
              <Button 
                type="submit" 
                size="sm" 
                className="w-full" 
                disabled={addingDomain || !newDomain.trim() || !resolvedZone}
              >
                {addingDomain ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Connect Domain
              </Button>
            </form>
          </div>
        </div>
      </DialogContent>

      {/* Confirm Remove Domain Dialog */}
      <AlertDialog open={!!confirmRemoveDomain} onOpenChange={(open) => !open && setConfirmRemoveDomain(null)}>
        <AlertDialogContent className="max-w-md border-border/60 shadow-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Domain?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove <span className="font-mono font-medium">{confirmRemoveDomain}</span> from this bucket? This will disconnect the custom domain.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => confirmRemoveDomain && handleRemoveDomain(confirmRemoveDomain)}
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}
