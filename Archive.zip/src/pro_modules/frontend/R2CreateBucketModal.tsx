import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Box, Loader2, Plus } from "lucide-react";
import { createR2Bucket, type R2Bucket } from "@/lib/r2";
import { useToast } from "@/components/ui/use-toast";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  existingBuckets: R2Bucket[];
  onCreated: () => void;
}

export function R2CreateBucketModal({ isOpen, onClose, existingBuckets, onCreated }: Props) {
  const [bucketName, setBucketName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (!isOpen) {
      setBucketName("");
      setError(null);
    }
  }, [isOpen]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setBucketName(val);
    
    if (!val) {
      setError(null);
      return;
    }
    
    // Cloudflare R2 bucket name rules: 3-63 chars, lowercase letters, numbers, hyphens.
    if (!/^[a-z0-9-]+$/.test(val)) {
      setError("Bucket name can only contain lowercase letters, numbers, and hyphens.");
      return;
    }
    
    if (existingBuckets.some(b => b.name === val)) {
      setError("A bucket with this name already exists.");
      return;
    }
    
    setError(null);
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (error || !bucketName) return;
    
    setIsCreating(true);
    try {
      await createR2Bucket(bucketName);
      toast({ title: "Bucket Created", description: `Successfully created ${bucketName}.` });
      onCreated(); // Triggers refresh
      onClose();
    } catch (err: any) {
      setError(err.toString());
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Box className="w-5 h-5 text-primary" />
            Create R2 Bucket
          </DialogTitle>
          <DialogDescription>
            Enter a unique name for your new bucket.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleCreate} className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Bucket Name</Label>
            <Input 
              placeholder="e.g. static-assets-prod"
              value={bucketName}
              onChange={handleNameChange}
              disabled={isCreating}
              autoFocus
            />
            {error && <p className="text-xs text-destructive mt-1">{error}</p>}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" type="button" onClick={onClose} disabled={isCreating}>
              Cancel
            </Button>
            <Button type="submit" disabled={!!error || !bucketName || isCreating}>
              {isCreating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
              Create Bucket
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
