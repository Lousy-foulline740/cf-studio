import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertCircle, File, UploadCloud } from "lucide-react";
import { open as openDialog } from "@tauri-apps/plugin-dialog";
import { stat } from "@tauri-apps/plugin-fs";
import { formatBytes } from "@/lib/utils";

interface R2UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  maxUploadSize?: number;
  onUpload: (localPath: string) => void;
}

export function R2UploadModal({ isOpen, onClose, maxUploadSize, onUpload }: R2UploadModalProps) {
  const [selectedFile, setSelectedFile] = useState<{ path: string; name: string; size: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSelectFile = async () => {
    try {
      setError(null);
      const selectedPath = await openDialog({
        multiple: false,
        directory: false,
        title: "Select File to Upload",
      });

      if (!selectedPath || Array.isArray(selectedPath)) return;

      const isWindows = selectedPath.includes('\\');
      const filename = selectedPath.split(isWindows ? '\\' : '/').pop() || "unknown_file";
      
      const fileStat = await stat(selectedPath);
      
      if (maxUploadSize && fileStat.size > maxUploadSize) {
        setError(`File size (${formatBytes(fileStat.size)}) exceeds the maximum allowed upload size of ${formatBytes(maxUploadSize)}.`);
        setSelectedFile({ path: selectedPath, name: filename, size: fileStat.size });
        return;
      }

      setSelectedFile({ path: selectedPath, name: filename, size: fileStat.size });
    } catch (err: any) {
      setError("Failed to select file: " + err.toString());
      setSelectedFile(null);
    }
  };

  const clearSelection = () => {
    setSelectedFile(null);
    setError(null);
  };

  const handleConfirm = () => {
    if (selectedFile && !error) {
      onUpload(selectedFile.path);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) {
        clearSelection();
        onClose();
      }
    }}>
      <DialogContent className="sm:max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-muted-foreground" />
            Upload File to R2
          </DialogTitle>
          <DialogDescription>
            Select a file from your computer to securely upload directly to the bucket.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-4">
          {!selectedFile ? (
            <div 
              className="border-2 border-dashed border-border rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-muted/30 transition-colors"
              onClick={handleSelectFile}
            >
              <File className="w-10 h-10 text-muted-foreground/50 mb-3" />
              <p className="text-sm font-medium">Click to select a file</p>
              {maxUploadSize && (
                <p className="text-xs text-muted-foreground mt-1">Maximum upload size: {formatBytes(maxUploadSize)}</p>
              )}
            </div>
          ) : (
            <div className={`border rounded-lg p-4 flex flex-col gap-3 ${error ? 'border-destructive/50 bg-destructive/5' : 'border-border bg-muted/20'}`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className={`p-2 rounded bg-background shrink-0 ${error ? 'text-destructive' : 'text-primary'}`}>
                    <File className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate" title={selectedFile.name}>{selectedFile.name}</p>
                    <p className="text-xs text-muted-foreground">{formatBytes(selectedFile.size)}</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={clearSelection} className="h-8 text-muted-foreground hover:text-foreground">
                  Change
                </Button>
              </div>
              
              {error && (
                <div className="text-xs text-destructive flex gap-1.5 items-start bg-destructive/10 p-2 rounded">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{error}</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => {
            clearSelection();
            onClose();
          }}>Cancel</Button>
          <Button 
            onClick={handleConfirm} 
            disabled={!selectedFile || !!error}
          >
            Confirm Upload
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
