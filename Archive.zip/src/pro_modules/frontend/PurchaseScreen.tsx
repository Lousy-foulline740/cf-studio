import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";

interface PurchaseScreenProps {
  onClose?: () => void;
}

export function PurchaseScreen({ onClose }: PurchaseScreenProps) {
  const [licenseKey, setLicenseKey] = useState("");
  const [isActivating, setIsActivating] = useState(false);
  const { toast } = useToast();

  const handleActivate = async () => {
    if (!licenseKey.trim()) {
      toast({
        title: "Missing License Key",
        description: "Please enter a valid license key to activate Pro features.",
        variant: "destructive",
      });
      return;
    }

    setIsActivating(true);
    // Simulate API verification delay
    setTimeout(() => {
      setIsActivating(false);
      toast({
        title: "Simulation Only",
        description: "License verification logic goes here. License key: " + licenseKey,
      });
    }, 800);
  };

  const handleOpenChange = (open: boolean) => {
    if (!open && onClose) {
      onClose();
    }
  };

  return (
    <Dialog open={true} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Upgrade to Pro</DialogTitle>
          <DialogDescription>
            Advanced data export and JSON/CSV formatting requires a Pro license.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col gap-4 py-4">
          <Card className="bg-muted/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">$2/month</CardTitle>
              <CardDescription>Monthly subscription</CardDescription>
            </CardHeader>
            <CardContent className="text-sm">
              <ul className="list-disc pl-4 space-y-1">
                <li>Export data to CSV and JSON formats.</li>
                <li>Select and filter specific columns for export.</li>
                <li>R2 Advanced Bucket Management</li>
                <li>D1 Interactive Index Management</li>
              </ul>
              <Button 
                variant="outline" 
                className="w-full mt-4" 
                onClick={() => window.open("https://cfstudio.dev/pro", "_blank")}
              >
                Purchase License
              </Button>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <label htmlFor="licenseKey" className="text-sm font-medium leading-none">
              Already have a license?
            </label>
            <Input
              id="licenseKey"
              placeholder="Enter your License Key"
              value={licenseKey}
              onChange={(e) => setLicenseKey(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="sm:justify-end">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="button" onClick={handleActivate} disabled={isActivating}>
            {isActivating ? "Activating..." : "Activate"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
