export function jsonToCsv(data: any[]): string {
  if (!Array.isArray(data) || data.length === 0) return "";

  const firstRow = data[0];
  const headers = firstRow && typeof firstRow === "object" ? Object.keys(firstRow) : [];

  const escapeValue = (value: unknown): string => {
    if (value === null || value === undefined) return "";
    const str = String(value);
    const needsQuotes = /[",\n\r]/.test(str);
    const escaped = str.replace(/"/g, '""');
    return needsQuotes ? `"${escaped}"` : escaped;
  };

  const lines: string[] = [];
  lines.push(headers.map(escapeValue).join(","));

  for (const row of data) {
    const line = headers.map((key) => escapeValue(row?.[key]));
    lines.push(line.join(","));
  }

  return lines.join("\n");
}
