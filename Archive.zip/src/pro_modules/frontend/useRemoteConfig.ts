import { useState, useEffect } from 'react';

interface ConfigData {
  is_export_free: boolean;
  current_version: string;
  max_r2_upload_size?: number;
  enable_r2_bucket_settings?: boolean;
  enable_d1_index_management?: boolean;
}

export function useRemoteConfig() {
  const [data, setData] = useState<ConfigData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let mounted = true;

    async function fetchConfig() {
      try {
        const response = await fetch('https://pro.cfstudio.dev/config.json?t=' + Date.now(), {
          cache: 'no-store',
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const jsonData = await response.json();
        if (mounted) {
          setData(jsonData);
          setIsLoading(false);
        }
      } catch (e) {
        if (mounted) {
          setError(e instanceof Error ? e : new Error(String(e)));
          setIsLoading(false);
        }
      }
    }

    fetchConfig();

    return () => {
      mounted = false;
    };
  }, []);

  return { data, isLoading, error };
}
