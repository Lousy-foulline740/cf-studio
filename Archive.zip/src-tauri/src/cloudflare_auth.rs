// cloudflare_auth.rs
//
// Reads the local Wrangler OAuth config to provide zero-touch authentication.
// No API tokens are ever stored in CF Studio — we reuse the session that
// `wrangler login` already created on the user's machine.

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;

use crate::cloudflare_client::{CfError, CfResponse, CloudflareClient};

// ── Error type ─────────────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum AuthError {
    #[error("Wrangler config directory not found. Is your home directory set?")]
    ConfigDirNotFound,

    #[error("Wrangler config file not found at {0}. Run `wrangler login` first.")]
    ConfigFileNotFound(String),

    #[error("Failed to read Wrangler config: {0}")]
    Io(#[from] std::io::Error),

    #[error("Failed to parse Wrangler config TOML: {0}")]
    TomlParse(#[from] toml::de::Error),

    #[error("No oauth_token found in Wrangler config. Run `wrangler login` first.")]
    NoToken,

    #[error("Command execution failed: {0}")]
    ExecError(String),
}

// Tauri requires errors to be serializable so they travel back to JS as strings.
impl Serialize for AuthError {
    fn serialize<S: serde::Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.to_string())
    }
}

// ── Wrangler config shape ──────────────────────────────────────────────────────

/// Only the fields we care about from `~/.config/.wrangler/config/default.toml`
#[derive(Debug, Deserialize)]
struct WranglerConfig {
    oauth_token: Option<String>,
    expiration_time: Option<String>,
    /// Wrangler sometimes stores the account_id it last used.
    account_id: Option<String>,
}

// ── Public result type returned to the frontend ────────────────────────────────

#[derive(Debug, Serialize, Clone)]
pub struct CloudflareCredentials {
    pub oauth_token: String,
    /// Present only when Wrangler has cached the account ID.
    pub account_id: Option<String>,
}

// ── Cloudflare Accounts ────────────────────────────────────────────────────────

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CloudflareAccount {
    pub id: String,
    pub name: String,
}

#[derive(Debug, thiserror::Error)]
pub enum AccountsError {
    #[error("Authentication error: {0}")]
    Auth(#[from] AuthError),

    #[error("HTTP error: {0}")]
    Http(#[from] reqwest::Error),

    #[error("Cloudflare API error(s): {0}")]
    Api(String),
}

impl Serialize for AccountsError {
    fn serialize<S: serde::Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.to_string())
    }
}

fn api_errors_to_string(errors: &[CfError]) -> String {
    errors
        .iter()
        .map(|e| format!("[{}] {}", e.code, e.message))
        .collect::<Vec<_>>()
        .join("; ")
}

// ── Path resolution ────────────────────────────────────────────────────────────

/// Returns candidate paths to search for the Wrangler `default.toml`, in
/// priority order. We try multiple because Wrangler's storage location has
/// changed across versions and differs per OS:
///
/// | Platform | Path |
/// |----------|------|
/// | macOS    | `~/Library/Preferences/.wrangler/config/default.toml` |
/// | Linux    | `~/.config/.wrangler/config/default.toml` |
/// | Windows  | `%USERPROFILE%\.wrangler\config\default.toml` |
///
/// We also add `~/.wrangler/config/default.toml` as a universal fallback
/// since older Wrangler versions stored it there on all platforms.
fn wrangler_candidate_paths() -> Vec<PathBuf> {
    let mut candidates: Vec<PathBuf> = Vec::new();

    // macOS: ~/Library/Preferences/.wrangler/config/default.toml
    // Linux: ~/.config/.wrangler/config/default.toml
    if let Some(pref) = dirs::preference_dir() {
        candidates.push(pref.join(".wrangler").join("config").join("default.toml"));
    }

    // Linux / XDG: ~/.config/.wrangler/config/default.toml
    if let Some(cfg) = dirs::config_dir() {
        candidates.push(cfg.join(".wrangler").join("config").join("default.toml"));
    }

    // Universal fallback: ~/.wrangler/config/default.toml
    if let Some(home) = dirs::home_dir() {
        candidates.push(
            home.join(".wrangler").join("config").join("default.toml"),
        );
        // Also try the old ~/.config/.wrangler path explicitly
        candidates.push(
            home.join(".config")
                .join(".wrangler")
                .join("config")
                .join("default.toml"),
        );
    }

    // De-duplicate while preserving order
    let mut seen = std::collections::HashSet::new();
    candidates.retain(|p| seen.insert(p.clone()));
    candidates
}

/// Returns the first existing Wrangler config path, or the primary candidate
/// path for use in error messages when none are found.
pub fn wrangler_config_path() -> Result<PathBuf, AuthError> {
    let candidates = wrangler_candidate_paths();
    if candidates.is_empty() {
        return Err(AuthError::ConfigDirNotFound);
    }

    // Prefer the first existing path in priority order (OS-specific default
    // first, then fallbacks). We avoid picking by mtime because multiple
    // Wrangler locations can exist on macOS and the newest one is not always
    // the active config used by Wrangler.
    for path in &candidates {
        if path.exists() {
            return Ok(path.clone());
        }
    }

    // None existed — return the primary candidate for a good error message
    Err(AuthError::ConfigFileNotFound(
        candidates[0].to_string_lossy().into_owned(),
    ))
}

// ── Core parsing logic ─────────────────────────────────────────────────────────

/// Reads and parses the Wrangler config, returning the extracted credentials.
pub fn read_credentials() -> Result<CloudflareCredentials, AuthError> {
    let candidates = wrangler_candidate_paths();
    if candidates.is_empty() {
        return Err(AuthError::ConfigDirNotFound);
    }

    let mut best: Option<(WranglerConfig, PathBuf)> = None;
    let mut saw_existing = false;
    let mut saw_no_token = false;
    let mut first_error: Option<AuthError> = None;

    for path in &candidates {
        if !path.exists() {
            continue;
        }
        saw_existing = true;

        let raw = match fs::read_to_string(path) {
            Ok(raw) => raw,
            Err(e) => {
                if first_error.is_none() {
                    first_error = Some(AuthError::Io(e));
                }
                continue;
            }
        };

        let config: WranglerConfig = match toml::from_str(&raw) {
            Ok(config) => config,
            Err(e) => {
                if first_error.is_none() {
                    first_error = Some(AuthError::TomlParse(e));
                }
                continue;
            }
        };

        if config.oauth_token.is_none() {
            saw_no_token = true;
            continue;
        }

        match &best {
            None => best = Some((config, path.clone())),
            Some((current, _)) => {
                let next_exp = config.expiration_time.as_deref();
                let current_exp = current.expiration_time.as_deref();

                let should_replace = match (current_exp, next_exp) {
                    (Some(cur), Some(next)) => next > cur,
                    (None, Some(_)) => true,
                    _ => false,
                };

                if should_replace {
                    best = Some((config, path.clone()));
                }
            }
        }
    }

    if let Some((config, _path)) = best {
        let oauth_token = config.oauth_token.ok_or(AuthError::NoToken)?;
        return Ok(CloudflareCredentials {
            oauth_token,
            account_id: config.account_id,
        });
    }

    if let Some(err) = first_error {
        return Err(err);
    }

    if saw_no_token {
        return Err(AuthError::NoToken);
    }

    if saw_existing {
        return Err(AuthError::NoToken);
    }

    Err(AuthError::ConfigFileNotFound(
        candidates[0].to_string_lossy().into_owned(),
    ))
}

// ── Background Token Refresh ───────────────────────────────────────────────────

/// Executes `wrangler whoami` silently in the background. Wrangler automatically
/// detects expired tokens and refreshes them during this command. We then
/// re-read the configuration file and return the fresh token.
#[tauri::command]
pub async fn refresh_wrangler_token() -> Result<CloudflareCredentials, AuthError> {
    let output = tokio::task::spawn_blocking(|| {
        let mut cmd = if cfg!(target_os = "windows") {
            let mut c = std::process::Command::new("cmd");
            c.args(["/c", "npx", "wrangler", "d1", "list"]);
            c
        } else {
            let mut c = std::process::Command::new("npx");
            c.args(["wrangler", "d1", "list"]);
            c
        };

        // Run silently
        cmd.output()
    })
    .await
    .map_err(|e| AuthError::ExecError(e.to_string()))?
    .map_err(AuthError::Io)?;

    if !output.status.success() {
        let err_msg = String::from_utf8_lossy(&output.stderr);
        return Err(AuthError::ExecError(format!("Wrangler failed to refresh token: {}", err_msg)));
    }

    // Re-read the credentials now that Wrangler has updated the config file
    tokio::task::spawn_blocking(read_credentials)
        .await
        .map_err(|e| AuthError::ExecError(e.to_string()))?
}

// ── Login ──────────────────────────────────────────────────────────────────────

#[tauri::command]
pub async fn run_wrangler_login() -> Result<(), AuthError> {
    tokio::task::spawn_blocking(|| {
        let mut cmd = if cfg!(target_os = "windows") {
            let mut c = std::process::Command::new("cmd");
            // use start to pop open a cmd window so they can see the prompt if any
            c.args(["/c", "start", "cmd", "/c", "npx wrangler login ^&^& pause"]);
            c
        } else {
            let mut c = std::process::Command::new("sh");
            // on macOS/Linux it should open the browser directly or we can use open/xdg-open
            c.args(["-c", "npx wrangler login"]);
            c
        };

        // Run silently
        let _ = cmd.output();
    })
    .await
    .map_err(|e| AuthError::ExecError(e.to_string()))?;

    Ok(())
}

pub fn start_wrangler_watcher(app: tauri::AppHandle) {
    use notify::{Watcher, RecursiveMode};
    use std::sync::mpsc::channel;
    use std::time::Duration;
    use tauri::Emitter;

    std::thread::spawn(move || {
        let (tx, rx) = channel();
        let mut watcher = match notify::recommended_watcher(tx) {
            Ok(w) => w,
            Err(e) => {
                eprintln!("Failed to start notify: {}", e);
                return;
            }
        };

        if let Some(mut path) = dirs::home_dir() {
            path.push(".wrangler");
            path.push("config");
            
            if !path.exists() {
                let _ = std::fs::create_dir_all(&path);
            }
            
            if watcher.watch(&path, RecursiveMode::NonRecursive).is_err() {
                eprintln!("Failed to watch wrangler config dir");
                return;
            }

            for res in rx {
                match res {
                    Ok(event) => {
                        let is_default_toml = event.paths.iter().any(|p| {
                            p.file_name().and_then(|n| n.to_str()) == Some("default.toml")
                        });
                        
                        if is_default_toml {
                            std::thread::sleep(Duration::from_millis(300));
                            if read_credentials().is_ok() {
                                let _ = app.emit("wrangler-session-updated", ());
                            } else {
                                let _ = app.emit("wrangler-session-deleted", ());
                            }
                        }
                    },
                    Err(e) => eprintln!("watch error: {:?}", e),
                }
            }
        }
    });
}

// ── Accounts API ───────────────────────────────────────────────────────────────

/// Fetches the list of Cloudflare accounts visible to the current OAuth token.
#[tauri::command]
pub async fn fetch_cloudflare_accounts() -> Result<Vec<CloudflareAccount>, AccountsError> {
    let creds = tokio::task::spawn_blocking(read_credentials)
        .await
        .unwrap_or_else(|e| {
            Err(AuthError::Io(std::io::Error::new(
                std::io::ErrorKind::Other,
                e.to_string(),
            )))
        })?;

    let client = CloudflareClient::new(&creds.oauth_token)?;

    let resp = client
        .get("accounts")
        .send()
        .await?
        .json::<CfResponse<Vec<CloudflareAccount>>>()
        .await?;

    if !resp.success {
        return Err(AccountsError::Api(api_errors_to_string(&resp.errors)));
    }

    Ok(resp.result.unwrap_or_default())
}

// ── Tests ──────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wrangler_path_ends_correctly() {
        // Just verify the path ends with the expected segments.
        // The home directory itself is environment-dependent.
        if let Ok(p) = wrangler_config_path() {
            let s = p.to_string_lossy();
            assert!(s.contains(".wrangler"), "path should contain .wrangler: {s}");
            assert!(s.ends_with("default.toml"), "path should end with default.toml: {s}");
        }
    }

    #[test]
    fn missing_config_returns_error() {
        // Simulate a non-existent file.
        let path = PathBuf::from("/tmp/__cf_studio_nonexistent_test_file.toml");
        assert!(!path.exists());
    }
}
