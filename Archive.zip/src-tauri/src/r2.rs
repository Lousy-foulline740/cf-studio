// r2.rs
//
// Cloudflare R2 — PUBLIC tier commands only.
// Pro commands (upload, download, create/delete bucket, settings) live in r2_pro.rs
// and are only compiled when the `pro` Cargo feature is enabled.
//
// Public commands: fetch_r2_buckets, list_r2_objects, delete_r2_object, get_r2_bucket_domain

use serde::{Deserialize, Serialize};

use crate::cloudflare_auth::{read_credentials, AuthError};
use crate::cloudflare_client::{CfError, CfResponse, CloudflareClient};

// ── Error type ─────────────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum R2Error {
    #[error("Authentication error: {0}")]
    Auth(#[from] AuthError),

    #[error("HTTP error: {0}")]
    Http(#[from] reqwest::Error),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Could not determine your Cloudflare account ID. Your account may not have API access.")]
    NoAccountId,

    #[error("Cloudflare API error(s): {0}")]
    Api(String),
}

impl Serialize for R2Error {
    fn serialize<S: serde::Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.to_string())
    }
}

// ── API types ──────────────────────────────────────────────────────────────────

/// Minimal account info from `GET /accounts`.
#[derive(Debug, Deserialize)]
struct CfAccount {
    id: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct R2Bucket {
    pub name: String,
    pub creation_date: String,
    pub object_count: Option<u64>,
    pub total_size_bytes: Option<u64>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BucketsResponse {
    pub buckets: Vec<R2Bucket>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct R2Object {
    pub key: String,
    pub size: u64,
    pub uploaded: String,
    pub etag: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ObjectsResponse {
    pub objects: Option<Vec<serde_json::Value>>,
    #[serde(rename = "delimitedPrefixes")]
    pub delimited_prefixes: Option<Vec<serde_json::Value>>,
    pub truncated: bool,
    pub cursor: Option<String>,
}

#[derive(Serialize)]
pub struct FolderListing {
    pub files: Vec<R2Object>,
    pub folders: Vec<String>,
}

// ── Helper ─────────────────────────────────────────────────────────────────────

fn api_errors_to_string(errors: &[CfError]) -> String {
    errors
        .iter()
        .map(|e| format!("[{}] {}", e.code, e.message))
        .collect::<Vec<_>>()
        .join("; ")
}

pub(crate) async fn resolve_account_id(client: &CloudflareClient) -> Result<String, R2Error> {
    let resp = client
        .get("accounts")
        .send()
        .await?
        .json::<CfResponse<Vec<CfAccount>>>()
        .await?;

    if !resp.success {
        return Err(R2Error::Api(api_errors_to_string(&resp.errors)));
    }

    let accounts = resp.result.unwrap_or_default();
    accounts
        .into_iter()
        .next()
        .map(|a| a.id)
        .ok_or(R2Error::NoAccountId)
}

// ── Public Tauri Commands ──────────────────────────────────────────────────────

/// Fetches the list of all R2 buckets for the authenticated Cloudflare account.
#[tauri::command]
pub async fn fetch_r2_buckets() -> Result<Vec<R2Bucket>, R2Error> {
    let creds = tokio::task::spawn_blocking(read_credentials)
        .await
        .map_err(|e| R2Error::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))??;

    let client = CloudflareClient::new(&creds.oauth_token)?;
    let account_id = match creds.account_id {
        Some(id) => id,
        None => resolve_account_id(&client).await?,
    };

    let resp = client
        .get(&format!("accounts/{}/r2/buckets", account_id))
        .send()
        .await?
        .json::<CfResponse<BucketsResponse>>()
        .await?;

    if !resp.success {
        return Err(R2Error::Api(api_errors_to_string(&resp.errors)));
    }

    let mut buckets = resp.result.map(|r| r.buckets).unwrap_or_default();

    // ── GraphQL Stats Fetching ───────────────────────────────────────────────
    let date_geq = chrono::Utc::now()
        .checked_sub_days(chrono::Days::new(2))
        .unwrap_or_else(chrono::Utc::now)
        .format("%Y-%m-%dT%H:%M:%SZ")
        .to_string();

    let query = format!(
        r#"query {{ viewer {{ accounts(filter: {{accountTag: "{account_id}"}}) {{ r2StorageAdaptiveGroups(limit: 1000, filter: {{datetime_geq: "{date_geq}"}}) {{ dimensions {{ bucketName }} max {{ objectCount payloadSize }} }} }} }} }}"#
    );

    let gql_resp = client
        .post("graphql")
        .json(&serde_json::json!({ "query": query }))
        .send()
        .await;

    if let Ok(gql_res) = gql_resp {
        if let Ok(data) = gql_res.json::<serde_json::Value>().await {
            if let Some(groups) = data["data"]["viewer"]["accounts"][0]["r2StorageAdaptiveGroups"].as_array() {
                let mut stats_map = std::collections::HashMap::new();
                for group in groups {
                    if let Some(bname) = group["dimensions"]["bucketName"].as_str() {
                        let count = group["max"]["objectCount"].as_u64().unwrap_or(0);
                        let size = group["max"]["payloadSize"].as_u64().unwrap_or(0);
                        stats_map.insert(bname.to_string(), (count, size));
                    }
                }

                for b in &mut buckets {
                    if let Some(&(count, size)) = stats_map.get(&b.name) {
                        b.object_count = Some(count);
                        b.total_size_bytes = Some(size);
                    } else {
                        b.object_count = Some(0);
                        b.total_size_bytes = Some(0);
                    }
                }
            }
        }
    }

    Ok(buckets)
}

/// Lists objects (files) and common prefixes (folders) at a specific prefix.
#[tauri::command]
pub async fn list_r2_objects(bucket_name: String, prefix: String) -> Result<FolderListing, R2Error> {
    let creds = tokio::task::spawn_blocking(read_credentials)
        .await
        .map_err(|e| R2Error::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))??;

    let client = CloudflareClient::new(&creds.oauth_token)?;
    let account_id = match creds.account_id {
        Some(id) => id,
        None => resolve_account_id(&client).await?,
    };

    let mut url = format!("accounts/{}/r2/buckets/{}/objects?delimiter=/", account_id, bucket_name);
    if !prefix.is_empty() {
        url = format!("{}&prefix={}", url, urlencoding::encode(&prefix));
    }

    let resp = client
        .get(&url)
        .send()
        .await?
        .json::<CfResponse<Vec<serde_json::Value>>>()
        .await?;

    if !resp.success {
        return Err(R2Error::Api(api_errors_to_string(&resp.errors)));
    }

    let all_objects = resp.result.unwrap_or_default();

    let mut files = Vec::new();
    let mut folders = std::collections::HashSet::new();

    // Cloudflare's REST API returns a flat array. We simulate folder architecture manually:
    for obj in all_objects {
        let key = obj["key"].as_str().unwrap_or("").to_string();

        if !prefix.is_empty() && !key.starts_with(&prefix) {
            continue;
        }

        let relative_path = if prefix.is_empty() {
            &key[..]
        } else {
            &key[prefix.len()..]
        };

        if let Some(slash_idx) = relative_path.find('/') {
            let folder_name = &relative_path[..=slash_idx];
            folders.insert(format!("{}{}", prefix, folder_name));
        } else {
            files.push(R2Object {
                key,
                size: obj["size"].as_u64().unwrap_or(0),
                uploaded: obj["last_modified"].as_str().unwrap_or(obj["uploaded"].as_str().unwrap_or("")).to_string(),
                etag: obj["etag"].as_str().unwrap_or("").to_string(),
            });
        }
    }

    if let Some(info) = resp.result_info {
        if let Some(delimited) = info.get("delimited").and_then(|v| v.as_array()) {
            for v in delimited {
                if let Some(s) = v.as_str() {
                    folders.insert(s.to_string());
                }
            }
        }
    }

    let mut folders_vec: Vec<String> = folders.into_iter().collect();
    folders_vec.sort();

    Ok(FolderListing { files, folders: folders_vec })
}

/// Deletes an object by key.
#[tauri::command]
pub async fn delete_r2_object(bucket_name: String, key: String) -> Result<(), R2Error> {
    let creds = tokio::task::spawn_blocking(read_credentials)
        .await
        .map_err(|e| R2Error::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))??;

    let client = CloudflareClient::new(&creds.oauth_token)?;
    let account_id = match creds.account_id {
        Some(id) => id,
        None => resolve_account_id(&client).await?,
    };

    let url = format!("accounts/{}/r2/buckets/{}/objects/{}", account_id, bucket_name, urlencoding::encode(&key));

    let resp = client
        .delete(&url)
        .send()
        .await?;

    if !resp.status().is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(R2Error::Api(format!("Delete failed: {}", text)));
    }

    Ok(())
}

/// Retrieves the public domain of a bucket. Checks custom domains first, then the managed .r2.dev sub-domain.
#[tauri::command]
pub async fn get_r2_bucket_domain(bucket_name: String) -> Result<Option<String>, R2Error> {
    let creds = tokio::task::spawn_blocking(read_credentials)
        .await
        .map_err(|e| R2Error::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))??;

    let client = CloudflareClient::new(&creds.oauth_token)?;
    let account_id = match creds.account_id {
        Some(id) => id,
        None => resolve_account_id(&client).await?,
    };

    // First, check for custom domains
    let custom_url = format!("accounts/{}/r2/buckets/{}/domains/custom", account_id, bucket_name);
    if let Ok(resp) = client.get(&custom_url).send().await {
        if let Ok(data) = resp.json::<serde_json::Value>().await {
            if let Some(domains) = data["result"]["domains"].as_array() {
                for d in domains {
                    if d["enabled"].as_bool().unwrap_or(false) {
                        if let Some(domain) = d["domain"].as_str() {
                            return Ok(Some(format!("https://{}", domain)));
                        }
                    }
                }
            }
        }
    }

    // Fallback: check managed domain
    let managed_url = format!("accounts/{}/r2/buckets/{}/domains/managed", account_id, bucket_name);
    if let Ok(resp) = client.get(&managed_url).send().await {
        if let Ok(data) = resp.json::<serde_json::Value>().await {
            if data["result"]["enabled"].as_bool().unwrap_or(false) {
                if let Some(domain) = data["result"]["domain"].as_str() {
                    return Ok(Some(format!("https://{}", domain)));
                }
            }
        }
    }

    Ok(None)
}
